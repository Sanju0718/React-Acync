export const ProfileIcon=()=>(
<svg
    width="24"
    height="56"
    viewBox="0 0 24 24"
    className="stroke-white group-hover:stroke-[#00B0B9]"
    fill="none"
    xmlns="http://www.w3.org/2000/svg">
    <g clip-path="url(#clip0_15997_1287)">
      <path
        d="M8 7C8 8.06087 8.42143 9.07828 9.17157 9.82843C9.92172 10.5786 10.9391 11 12 11C13.0609 11 14.0783 10.5786 14.8284 9.82843C15.5786 9.07828 16 8.06087 16 7C16 5.93913 15.5786 4.92172 14.8284 4.17157C14.0783 3.42143 13.0609 3 12 3C10.9391 3 9.92172 3.42143 9.17157 4.17157C8.42143 4.92172 8 5.93913 8 7Z"
        stroke=""
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        d="M5 21V19C5 17.9391 5.49167 16.9217 6.36683 16.1716C7.242 15.4214 8.42899 15 9.66667 15H14.3333C15.571 15 16.758 15.4214 17.6332 16.1716C18.5083 16.9217 19 17.9391 19 19V21"
        stroke=""
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </g>
    <defs>
      <clipPath id="clip0_15997_1287">
        <rect width="24" height="24" fill="" />
      </clipPath>
    </defs>
  </svg>

);