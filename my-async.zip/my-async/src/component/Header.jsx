import React, { useState } from "react";
import { images } from "../assets/images";
import { HeartIcon } from "../assets/images/icons/HeartIcon";
import { ProfileIcon } from "../assets/images/icons/ProfileIcon";
import { CartIcon } from "../assets/images/icons/CartIcon";
import { Link } from "react-router-dom";

export default function Header() {
  const [menuClick, setMenuClick] = useState(false);
  const menufunction = () => {
    setMenuClick(!menuClick);
  };
  return (
    <div className="absolute top-0 left-0 right-0 z-10">
      <div className="container-custom">
        <div className=" bg-black flex xl:py-[20px] lg:py-[10px] md:py-[5px] xl:px-[32px] md:px-[16px] rounded-[24px] justify-between items-center">
          <div className="order-2 lg:order-none">
            <img
              className="xl:w-[209px] w-[150px]"
              src={images.IQBiologix}
              alt=""
            />
          </div>
          <button onClick={menufunction}>
            <div className="lg:hidden ml-4">
              <img src={images.menu} alt="" />
            </div>
          </button>

          <div
            className={
              menuClick
                ? "flex flex-col fixed top-0 left-0 h-full bg-red-300 transition-transform duration-300 translate-x-0 ease-in-out z-40"
                : "lg:flex hidden  2xl:gap-[48px] xl:gap-[44px] gap-[20px]"
            }
            // onClick={menufunction}
          >
            <button onClick={menufunction} className="lg:hidden block ">
              closed
            </button>
            <>
              <a href="#" className="header-link text-white uppercase">
                home
              </a>
              <a href="#" className="header-link text-white uppercase">
                Shop Products
              </a>
              <a href="#" className="header-link text-white uppercase">
                about
              </a>
              <a href="#" className="header-link text-white uppercase">
                learn
              </a>
              <a href="#" className="header-link text-white uppercase">
                contact
              </a>
            </>
          </div>

          <div className=" flex items-center  order-3 lg:order-none lg:mr-0 mr-4">
            <div className="flex items-center lg:bg-gray py-[9.5px] px-[8px] lg:border-grayBorder border-2 border-none rounded-[24px]">
              <img
                src={images.search}
                alt="search"
                className="block md:hidden"
              />
              <img
                src={images.searchMobile}
                alt="search"
                className="md:block hidden"
              />
              <input
                className="bg-gray ml-2 xl:w-[320px] w-[220px] text-white outline-0 lg:flex hidden"
                placeholder="Search products"
              />
            </div>
            <div className="xl:ml-[24px] ml-[12px] lg:flex hidden">
              <button>
                <HeartIcon />
              </button>
            </div>
            <div className="xl:pl-[24px] pl-[12px] lg:flex hidden relative items-center justify-center user-block leading-[0]">
              <div className="group relative inline-block">
                {/* Profile Icon */}
                <span className="inline-block">
                  <i className="relative cursor-pointer icon">
                    <ProfileIcon />
                  </i>
                </span>

                {/* Dropdown */}
                <ul className="hidden group-hover:flex pointer-events-auto shadow-lg absolute top-14 left-[50%] -translate-x-[50%] flex-col min-w-40 bg-white text-center z-[11]">
                  <li className="text-blue-500 py-3 h-full text-xs border-t border-gray-200 first:border-t-0 hover:bg-gray-100">
                    <Link to="/signup">SignUp</Link>
                  </li>
                  <li className="text-blue-500 py-3 h-full text-xs border-t border-gray-200 first:border-t-0 hover:bg-gray-100">
                    <Link to="/login">Login</Link>
                  </li>
                </ul>
              </div>
            </div>

            <div className="xl:pl-[24px] pl-[12px]">
              <button>
                <CartIcon />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
