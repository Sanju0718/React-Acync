/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx,scss}"
  ],
  theme: {
    extend: {
      colors: {
        gray: "#262626",
        grayBorder: "#404040",
        lightSky: "#00B0B9",
        black17: "#171717",
        grayborder: "#404040",
        lightWhite: "#D4D4D4",
        grayTexts: "#737373",
        green: "#E8FF3E",
        grayF5: "#F5F5F5",
        grayA3: "#A3A3A3",
        grayE5: "#E5E5E5",
        whiteFA: "#FAFAFA",
        white40: "#FFFFFF40",
      },
    },
  },
  plugins: [],
}

